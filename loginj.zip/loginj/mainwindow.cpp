#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QMessageBox>


MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    QSqlDatabase mydb= QSqlDatabase::addDatabase("QSQLITE");
    mydb.setDatabaseName("/home/jason/login/jason.db");

    if(!mydb.open())
        ui->label_status->setText("Failed to open the database");
    else
        ui->label_status->setText("connected");
}


MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::on_pushButton_login_clicked()
{
    QString username = ui->lineEdit_username->text();
    QString password = ui->lineEdit_password->text();

    QSqlQuery query;
           query.exec("create table jason(username, password)");
           if(query.exec("select * from jason where username='" + username + "' and password='" + password + "'"))
           {
            int count = 0;
               while(query.next())
               {
                 count++;
               }
               if(count == 1){{
                loginDialog = new LoginDialog(this);
                loginDialog->show();
               }
            }
            else
            {
             QMessageBox::information(this,"Error","Incorrect input or not registered");
            }}

}

void MainWindow::on_pushButton_register_clicked()
{
    QString username1, password;
        username1 = ui->lineEdit_username->text();
        password = ui->lineEdit_password->text();
        ui->lineEdit_username->clear();
        ui->lineEdit_password->clear();
        QSqlQuery query;
        if(username1 != "" || password != "")
        {
            if(query.exec("select * from jason where username='" + username1 + "' and password='" + password + "'"))
            {
                int count = 0;
                while(query.next())
                {
                    count++;
                }
                if(count == 1)
                {
                    QMessageBox::information(this,"Error","User already exists");
                }
                else
                {
                    if(query.exec("insert into jason (username, password) values ('" + username1 + "','" + password + "')"))
                    {
                        QMessageBox::information(this,"Success","You have successfully registered");

                        }

                    else
                    {
                        QMessageBox::warning(this, "Error", "Registration failed");
                    }
                }
            }
        }
        else{
            QMessageBox::information(this, "Information", "Enter username and password to register.");
        }
}
