#include "regdialog.h"
#include "ui_regdialog.h"
#include<QDir>
#include<QString>
#include<QPixmap>
#include <QSqlDatabase>
#include <QSqlQuery>
#include<QMessageBox>
#include"qdebug.h"
#include<QFileDialog>
#include<QProcess>
#include<QFile>
#include<QMovie>
#include<QSize>

RegDialog::RegDialog(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::RegDialog)
{
    ui->setupUi(this);
}

RegDialog::~RegDialog()
{
    delete ui;
}

void RegDialog::on_pushButton_register1_clicked()
{
    QString username1, password1;
       username1 = ui->lineEdit_username1 ->text();
       password1 = ui->lineEdit_password1 ->text();
       QSqlQuery query;
       if(username1 != "" || password1 != "")
       {
           if(query.exec("select * from user1 where username='" + username1 + "' and password='" + password1 + "'"))
           {
               int count = 0;
               while(query.next())
               {
                   count++;
               }
               if(count == 1)
               {
                   QMessageBox::information(this,"Error","User already exists. Try logging in.", QMessageBox::Ok);
               }
               else
               {
                   if(query.exec("insert into user1 (username, password) values ('" + username1 + "','" + password1 + "')"))
                   {
                       QMessageBox::information(this,"Registration Success","You have successfully registered",QMessageBox::Ok);

                   }
                   else
                   {
                       QMessageBox::information(this, "Error", "Registration failed. Try again", QMessageBox::Ok);
                   }
               }
           }
       }
       else{
           QMessageBox::information(this, "Information", "Enter username and password to register.", QMessageBox::Ok);
       }
}
